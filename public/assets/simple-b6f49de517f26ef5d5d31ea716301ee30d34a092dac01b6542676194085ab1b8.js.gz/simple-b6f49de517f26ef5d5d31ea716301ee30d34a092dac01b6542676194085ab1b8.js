$(function () {
	$('#defaultCountdown').countdown({until: '+1m +15s', format: 'YOWDHMS', significant: 3});
});
